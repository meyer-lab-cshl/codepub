Installation
=============================

You can install the package with pip:

.. code-block:: python

	pip install codepub

Or with conda:

.. code-block:: python

	conda install -c vasilisa.kovaleva codepub

Requirements
--------------------
- numpy>=1.23.5
	.. code-block:: python

		pip install "numpy>=1.23.5"