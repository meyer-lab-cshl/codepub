from importlib.metadata import version
__version__ = version("codepub")

from codepub.functions import *