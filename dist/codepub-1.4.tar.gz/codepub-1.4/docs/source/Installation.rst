Installation
=============================

You can install the package with pip:

.. code-block:: python

	pip install codepub

Or with conda:

.. code-block:: python

	conda install -c vasilisa.kovaleva codepub

Requirements
--------------------
